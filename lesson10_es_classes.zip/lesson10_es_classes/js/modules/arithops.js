/**
 * arithops.js
 */

const add = function(n1, n2) {
    return n1 + n2;
};

const subtract = function(n1, n2) {
    return n1 - n2;
}

const multiply = function(n1, n2) {
    return n1 * n2;
}

// export { add, subtract, multiply };
export default subtract;
// export default { add, subtract };